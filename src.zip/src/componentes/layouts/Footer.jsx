import React from 'react'

export const Footer = () => {
  return (
    <footer className="footer">
    &copy; Máster en React - <a href="https://manuelHernandezHerrera.com">manuelHernandezHerrera.com</a>
    </footer>

  )
}
